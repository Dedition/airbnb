import React from 'react'

function Footer() {
    return (
        <div className='footer'>
            <p>© 2022 Airbnb clone! No rights reserved.</p>
        </div>
    )
}

export default Footer;
